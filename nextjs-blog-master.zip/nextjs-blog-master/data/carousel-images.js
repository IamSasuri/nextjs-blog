const CarouselImages = [
    {
        'img' : '/images/image.jpg'
    },
    {
        'img' : '/images/37368.jpg'
    },
    {
        'img' : '/images/itachi-uchiha-naruto-amoled-black-background-5k-5800x3197-4962.png'
    },
    {
        'img' : '/images/itachi-uchiha-naruto-amoled-black-background-minimal-art-3840x2160-6478.png'
    },
]

export default CarouselImages