const nav = [
    {
        name:'HomePage',
        href:'/',
    },
    {
        name:'LifeStyle',
        href:'/category/Lifestyle',
    },
    {
        name:'Technology',
        href:'/category/Technology',
    },
    {
        name:'Latest',
        href:'/latest',
    }
]

export default nav